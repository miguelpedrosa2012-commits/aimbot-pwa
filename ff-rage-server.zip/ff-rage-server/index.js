// language: Node.js, file: index.js
// FF RAGE — HTTPS intercepting proxy + config API
// Deploy: arrasta esta pasta pro Replit e clica Run

const net       = require('net');
const tls       = require('tls');
const http      = require('http');
const https     = require('https');
const fs        = require('fs');
const path      = require('path');
const forge     = require('node-forge');
const express   = require('express');
const cors      = require('cors');
const fetch     = require('node-fetch');

// ─── Paths ───────────────────────────────────────────────────
const DATA_DIR  = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);

const CA_PEM    = path.join(DATA_DIR, 'ca.pem');
const CA_KEY    = path.join(DATA_DIR, 'ca.key');
const CFG_FILE  = path.join(DATA_DIR, 'config.json');

// ─── Default rage config ─────────────────────────────────────
const DEFAULT_CONFIG = {
  pipeline_active:        true,
  aim_x_lock:             20,
  aim_x_magnetic:         20,
  aim_x_correction:       1.0,
  aim_y_assist:           20,
  aim_y_compensation:     20,
  head_lock_precision:    1.0,
  bone_offset_y:          -0.10,
  snap_enabled:           true,
  snap_strength:          1.0,
  snap_confirm_frames:    1,
  snap_min_confidence:    0.40,
  snap_duration_ms:       4,
  snap_on_hip:            true,
  snap_on_ads:            true,
  headtrick_enabled:      true,
  headtrick_strength:     1.0,
  headtrick_offset_ms:    0,
  headtrick_duration_ms:  4,
  recoil_reduction:       0.95,
  recoil_vertical:        0.95,
  recoil_horizontal:      0.95,
  recoil_control:         2.0,
  sensitivity:            100,
  dead_zone_px:           0.5,
  correction_strength:    1.0,
  max_correction_px:      30,
  lead_ms:                30,
  lead_idle_cutoff:       false,
  strafe_weight:          0.9,
  max_lead_px:            60,
  smooth:                 0.20,
  fov_base:               300,
  fov_max:                300,
  boost_headshot:         5.0,
  confidence_min:         0.35,
  scan_interval_ms:       8,
};

let config = { ...DEFAULT_CONFIG };
if (fs.existsSync(CFG_FILE)) {
  try { config = { ...DEFAULT_CONFIG, ...JSON.parse(fs.readFileSync(CFG_FILE)) }; }
  catch (_) {}
}
const saveConfig = () => fs.writeFileSync(CFG_FILE, JSON.stringify(config, null, 2));

// ─── Stats ───────────────────────────────────────────────────
let stats = { intercepted: 0, modified: 0, started: Date.now() };
let targets = [];
let sseClients = [];

// ─── CA Certificate ──────────────────────────────────────────
let caCert, caKey;

function generateCA() {
  console.log('[CA] Generating CA certificate...');
  const keys = forge.pki.rsa.generateKeyPair(2048);
  const cert = forge.pki.createCertificate();
  cert.publicKey = keys.publicKey;
  cert.serialNumber = '01';
  cert.validity.notBefore = new Date();
  cert.validity.notAfter  = new Date();
  cert.validity.notAfter.setFullYear(cert.validity.notBefore.getFullYear() + 10);
  const attrs = [
    { name: 'commonName',         value: 'FF Rage CA' },
    { name: 'organizationName',   value: 'FF Config'  },
    { name: 'countryName',        value: 'BR'         },
  ];
  cert.setSubject(attrs);
  cert.setIssuer(attrs);
  cert.setExtensions([
    { name: 'basicConstraints', cA: true },
    { name: 'keyUsage', keyCertSign: true, cRLSign: true },
    { name: 'subjectKeyIdentifier' },
  ]);
  cert.sign(keys.privateKey, forge.md.sha256.create());
  fs.writeFileSync(CA_PEM, forge.pki.certificateToPem(cert));
  fs.writeFileSync(CA_KEY, forge.pki.privateKeyToPem(keys.privateKey));
  console.log('[CA] Certificate generated');
  return { cert, key: keys.privateKey };
}

function loadOrCreateCA() {
  if (fs.existsSync(CA_PEM) && fs.existsSync(CA_KEY)) {
    caCert = forge.pki.certificateFromPem(fs.readFileSync(CA_PEM, 'utf8'));
    caKey  = forge.pki.privateKeyFromPem(fs.readFileSync(CA_KEY, 'utf8'));
    console.log('[CA] Loaded existing CA');
  } else {
    const ca = generateCA();
    caCert = ca.cert;
    caKey  = ca.key;
  }
}

function generateHostCert(hostname) {
  const keys = forge.pki.rsa.generateKeyPair(2048);
  const cert = forge.pki.createCertificate();
  cert.publicKey = keys.publicKey;
  cert.serialNumber = Date.now().toString(16);
  cert.validity.notBefore = new Date();
  cert.validity.notAfter  = new Date();
  cert.validity.notAfter.setFullYear(cert.validity.notBefore.getFullYear() + 2);
  const attrs = [{ name: 'commonName', value: hostname }];
  cert.setSubject(attrs);
  cert.setIssuer(caCert.subject.attributes);
  cert.setExtensions([
    { name: 'basicConstraints', cA: false },
    { name: 'subjectAltName', altNames: [{ type: 2, value: hostname }] },
  ]);
  cert.sign(caKey, forge.md.sha256.create());
  return {
    cert: forge.pki.certificateToPem(cert),
    key:  forge.pki.privateKeyToPem(keys.privateKey),
  };
}

// ─── Injection ───────────────────────────────────────────────
const INJECT_MAP = [
  ['aim_assist',        () => config.aim_x_lock],
  ['aim_lock',          () => config.aim_x_lock],
  ['head_lock',         () => Math.round(config.head_lock_precision * 100)],
  ['snap_strength',     () => config.snap_strength],
  ['snap',              () => config.snap_strength],
  ['headtrick',         () => config.headtrick_strength],
  ['recoil',            () => config.recoil_reduction],
  ['sensitivity',       () => config.sensitivity],
  ['dead_zone',         () => config.dead_zone_px],
  ['smooth',            () => config.smooth],
  ['fov_max',           () => config.fov_max],
  ['boost_headshot',    () => config.boost_headshot],
  ['correction',        () => config.correction_strength],
  ['lead_ms',           () => config.lead_ms],
  ['magnetic',          () => config.aim_x_magnetic],
  ['assist',            () => config.aim_y_assist],
  ['compensation',      () => config.aim_y_compensation],
];

function injectValues(obj) {
  if (typeof obj !== 'object' || obj === null) return obj;
  for (const key of Object.keys(obj)) {
    const lk = key.toLowerCase().replace(/[-. ]/g, '_');
    let injected = false;
    for (const [pattern, valFn] of INJECT_MAP) {
      if (lk.includes(pattern)) {
        obj[key] = valFn();
        injected = true;
        break;
      }
    }
    if (!injected && typeof obj[key] === 'object') {
      obj[key] = injectValues(obj[key]);
    }
  }
  return obj;
}

function tryInject(body, host) {
  if (!config.pipeline_active) return { body, modified: false };
  const str = body.toString();
  if (!str.trim().startsWith('{') && !str.trim().startsWith('[')) return { body, modified: false };
  try {
    const parsed = JSON.parse(str);
    const original = JSON.stringify(parsed);
    const injected = injectValues(parsed);
    const result   = JSON.stringify(injected);
    if (result !== original) {
      stats.modified++;
      console.log(`[INJECT] ${host} — modified`);
      return { body: Buffer.from(result), modified: true };
    }
  } catch (_) {}
  return { body, modified: false };
}

// ─── HTTPS Intercepting Proxy ────────────────────────────────
const FF_HOSTS = [
  'garena.com', 'ff.garena.com', 'cdn.ff.garena.com',
  'config.ff.garena.com', 'ffmobile.garena.com',
  'ffsea.garena.com', 'ffvng.garena.com', 'ffth.garena.com',
  'gop.garena.com', 'gameconfig.garena.com',
  'seagameconf.garena.com', 'ff-game.garena.com',
  'sopgame.garena.com',
];
const isFFHost = h => FF_HOSTS.some(d => h === d || h.endsWith('.' + d));

const proxyServer = http.createServer((req, res) => {
  res.writeHead(400);
  res.end('Use CONNECT for HTTPS');
});

proxyServer.on('connect', (req, clientSocket, head) => {
  const [hostname, portStr] = req.url.split(':');
  const port = parseInt(portStr) || 443;
  stats.intercepted++;

  if (!isFFHost(hostname)) {
    // Transparent tunnel
    const serverSocket = net.connect(port, hostname, () => {
      clientSocket.write('HTTP/1.1 200 Connection Established\r\n\r\n');
      serverSocket.write(head);
      serverSocket.pipe(clientSocket);
      clientSocket.pipe(serverSocket);
    });
    serverSocket.on('error', () => clientSocket.destroy());
    clientSocket.on('error', () => serverSocket.destroy());
    return;
  }

  // FF host — MITM
  clientSocket.write('HTTP/1.1 200 Connection Established\r\n\r\n');

  const hostCert = generateHostCert(hostname);
  const tlsServer = new tls.TLSSocket(clientSocket, {
    isServer: true,
    cert: hostCert.cert,
    key:  hostCert.key,
  });

  tlsServer.on('error', () => {});
  tlsServer.on('data', (data) => {
    const reqStr = data.toString();
    const firstLine = reqStr.split('\r\n')[0];

    const serverSocket = tls.connect({ host: hostname, port, servername: hostname }, () => {
      serverSocket.write(data);
    });

    let responseChunks = [];
    serverSocket.on('data', chunk => responseChunks.push(chunk));
    serverSocket.on('end', () => {
      const full = Buffer.concat(responseChunks);
      const headerEnd = full.indexOf('\r\n\r\n');
      if (headerEnd === -1) { tlsServer.write(full); return; }

      const headerBuf = full.slice(0, headerEnd + 4);
      const bodyBuf   = full.slice(headerEnd + 4);
      const headerStr = headerBuf.toString();
      const isJson    = headerStr.includes('application/json') ||
                        headerStr.includes('text/plain');

      if (isJson && bodyBuf.length > 0) {
        const { body: injectedBody } = tryInject(bodyBuf, hostname);
        const newHeader = headerStr.replace(
          /Content-Length:\s*\d+/i,
          `Content-Length: ${injectedBody.length}`
        );
        tlsServer.write(Buffer.from(newHeader));
        tlsServer.write(injectedBody);
      } else {
        tlsServer.write(full);
      }
    });

    serverSocket.on('error', () => tlsServer.destroy());
    tlsServer.on('error', () => serverSocket.destroy());
  });
});

// ─── Config API ───────────────────────────────────────────────
const api = express();
api.use(cors());
api.use(express.json());

api.get('/config', (_, res) => res.json(config));

api.patch('/config', (req, res) => {
  config = { ...config, ...req.body };
  saveConfig();
  res.json(config);
});

api.get('/cert', (_, res) => {
  res.setHeader('Content-Type', 'application/x-pem-file');
  res.setHeader('Content-Disposition', 'attachment; filename="FF_CA.pem"');
  res.send(fs.readFileSync(CA_PEM));
});

api.get('/mobileconfig', async (_, res) => {
  let publicIP = '127.0.0.1';
  try {
    const r = await fetch('https://api.ipify.org?format=json');
    const j = await r.json();
    publicIP = j.ip;
  } catch (_) {}

  const certPem  = fs.readFileSync(CA_PEM, 'utf8');
  const certB64  = Buffer.from(certPem).toString('base64');
  const proxyPort = process.env.PROXY_PORT || 8080;

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>PayloadContent</key>
  <array>
    <dict>
      <key>PayloadType</key><string>com.apple.security.root</string>
      <key>PayloadIdentifier</key><string>com.ffrage.cert</string>
      <key>PayloadUUID</key><string>A1B2C3D4-0001-0001-0001-000000000001</string>
      <key>PayloadVersion</key><integer>1</integer>
      <key>PayloadDisplayName</key><string>FF Rage CA</string>
      <key>PayloadContent</key>
      <data>${certB64}</data>
    </dict>
    <dict>
      <key>PayloadType</key><string>com.apple.proxy.managed</string>
      <key>PayloadIdentifier</key><string>com.ffrage.proxy</string>
      <key>PayloadUUID</key><string>B2C3D4E5-0002-0002-0002-000000000002</string>
      <key>PayloadVersion</key><integer>1</integer>
      <key>PayloadDisplayName</key><string>FF Rage Proxy</string>
      <key>HTTPEnable</key><true/>
      <key>HTTPProxy</key><string>${publicIP}</string>
      <key>HTTPPort</key><integer>${proxyPort}</integer>
      <key>HTTPSEnable</key><true/>
      <key>HTTPSProxy</key><string>${publicIP}</string>
      <key>HTTPSPort</key><integer>${proxyPort}</integer>
      <key>HTTPProxyCaptiveLoginAllowed</key><true/>
    </dict>
  </array>
  <key>PayloadDisplayName</key><string>FF RAGE</string>
  <key>PayloadDescription</key><string>Configuração de rede FF</string>
  <key>PayloadIdentifier</key><string>com.ffrage.profile</string>
  <key>PayloadType</key><string>Configuration</string>
  <key>PayloadUUID</key><string>C3D4E5F6-0000-0000-0000-000000000000</string>
  <key>PayloadVersion</key><integer>1</integer>
</dict>
</plist>`;

  res.setHeader('Content-Type', 'application/x-apple-aspen-config');
  res.setHeader('Content-Disposition', 'attachment; filename="FF_RAGE.mobileconfig"');
  res.send(xml);
});

api.get('/stats', (_, res) => {
  res.json({
    intercepted: stats.intercepted,
    modified:    stats.modified,
    uptime_seconds: Math.floor((Date.now() - stats.started) / 1000),
    config,
  });
});

api.post('/targets', (req, res) => {
  const t = { ...req.body, timestamp: Date.now() };
  targets.unshift(t);
  if (targets.length > 200) targets.pop();
  sseClients.forEach(c => c.write(`data: ${JSON.stringify(t)}\n\n`));
  res.json({ ok: true });
});

api.get('/targets/stream', (req, res) => {
  res.setHeader('Content-Type',  'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection',    'keep-alive');
  res.flushHeaders();
  sseClients.push(res);
  req.on('close', () => {
    sseClients = sseClients.filter(c => c !== res);
  });
});

// ─── Start ────────────────────────────────────────────────────
loadOrCreateCA();

const PROXY_PORT = parseInt(process.env.PROXY_PORT) || 8080;
const API_PORT   = parseInt(process.env.PORT)        || 3000;

proxyServer.listen(PROXY_PORT, '0.0.0.0', () =>
  console.log(`[PROXY] Listening on :${PROXY_PORT}`)
);

api.listen(API_PORT, '0.0.0.0', () =>
  console.log(`[API] Listening on :${API_PORT}`)
);
